Ext.define('Shopware.apps.TkVariants.view.detail.Window', {
    extend: 'Shopware.window.Detail',
    alias: 'widget.tk-variants-detail-window',
    height: 450,
    width: 900,
    title: 'Add new record'

})
